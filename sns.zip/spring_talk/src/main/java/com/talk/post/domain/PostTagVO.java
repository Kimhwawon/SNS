package com.talk.post.domain;

import lombok.Data;

@Data
public class PostTagVO {
	private int post_num;
	private int tag_num;
}
