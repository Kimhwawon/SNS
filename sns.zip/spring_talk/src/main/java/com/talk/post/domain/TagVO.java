package com.talk.post.domain;

import lombok.Data;

@Data
public class TagVO {
	private int tag_num;
	private String tag;
}
