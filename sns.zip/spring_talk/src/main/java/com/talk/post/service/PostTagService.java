package com.talk.post.service;

public interface PostTagService {

}
