package com.talk.post.domain;

import lombok.Data;

@Data
public class Criteria {
	private int page_num = 1;
	private int number = 10;
	
}
