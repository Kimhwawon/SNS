package com.talk.post.mapper;

public interface PostAtMapper {

}