package com.talk.post.domain;

import lombok.Data;

@Data
public class PostAtVO {
	private int post_num;
	private String user_id;
}
