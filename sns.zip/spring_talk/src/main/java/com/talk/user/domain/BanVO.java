package com.talk.user.domain;

import lombok.Data;

@Data
public class BanVO {
	
	private String user_id;
	private String ban_id;
}
