package com.talk.report.domain;

import lombok.Data;

@Data
public class ReportReplyVO {
	private long report_reply_num;
	private String report_id;
	private String report_reason;

}
